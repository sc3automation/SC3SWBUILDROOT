/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2017 NXP
 */

#ifndef _ASM_ARCH_SYS_PROTO_H
#define _ASM_ARCH_SYS_PROTO_H

#include <asm/mach-imx/sys_proto.h>

#endif /* _ASM_ARCH_SYS_PROTO_H */
